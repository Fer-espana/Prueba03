Manual Técnico
=====================================

Este manual esta orientado a proporcionar documentacion sobre las estructuras que se manejaron en el proyecto

### 1 Unidad De Usuarios (Lista SImplemente Enlazada)

### 1.1\. Visión General

El módulo Usuarios es el componente central de la aplicación, encargado de gestionar la información de los usuarios y las estructuras de datos asociadas a ellos. Utiliza una **lista enlazada simple** para almacenar los registros de usuario y proporciona funciones para su manipulación, búsqueda y generación de informes visuales.

### 1.2\. Estructuras de Datos

El módulo define dos estructuras principales para la gestión de usuarios:

*   **TUsuario**: Un registro (record) que representa a un usuario individual. Cada usuario contiene sus datos personales y, lo que es más importante, referencias a otras estructuras de datos que gestionan sus correos, contactos y más:
    
    *   id (Integer): Identificador único del usuario.
        
    *   nombre, usuario, password, email, telefono (String): Atributos de información personal.
        
    *   inbox (**TListaCorreos**): Una lista doblemente enlazada para la bandeja de entrada de correos del usuario.
        
    *   contacts (**TListaContactos**): Una lista enlazada circular para los contactos del usuario.
        
    *   papelera (**TPila**): Una estructura de pila para los correos eliminados.
        
    *   programados (**TCola**): Una estructura de cola para los correos programados.
        
    *   siguiente (**PUsuario**): Un puntero al siguiente usuario en la lista enlazada principal.
        
*   **TListaUsuarios**: Un registro que representa la lista completa de usuarios. Solo contiene un puntero al primer usuario de la lista:
    
    *   primero (**PUsuario**): Un puntero al primer nodo de la lista enlazada de usuarios.
        

Además de estas estructuras, se definen dos variables globales para el estado de la aplicación:

*   ListaUsuarios (TListaUsuarios): La lista principal que contiene a todos los usuarios registrados.
    
*   UsuarioLogueado (PUsuario): Un puntero al usuario que ha iniciado sesión actualmente.
    

### 1.3\. Procedimientos y Funciones Clave

Este módulo expone una serie de procedimientos y funciones para interactuar con las estructuras de datos de usuarios:

        Función/Procedimiento	Descripción
        InicializarLista	Inicializa la lista de usuarios, estableciendo el puntero primero a nil.
        AgregarUsuario	Crea un nuevo usuario, inicializa sus sub-estructuras (inbox, contacts, etc.) y lo añade al final de la lista enlazada de usuarios.
        MostrarUsuariosEnGUI	Recorre la lista de usuarios y muestra sus datos en una ventana emergente (ShowMessage) de la interfaz gráfica.
        BuscarUsuario	Busca un usuario en la lista por su dirección de correo electrónico.
        BuscarUsuarioPorID	Busca un usuario en la lista por su identificador único (id).
        GenerarReportes	Procedimiento principal que coordina la generación de varios informes para un usuario específico. Crea una carpeta dedicada a los reportes del usuario y llama a los procedimientos de generación individuales.
        GenerarGraphvizUsuarios	Genera un archivo .dot que representa la estructura de la lista enlazada de usuarios, permitiendo la visualización del flujo de la lista.
        GenerarReporteContactos, GenerarReporteCorreos, GenerarReportePapelera, GenerarReporteProgramados	Estos procedimientos crean archivos .dot específicos para las sub-estructuras de datos del usuario (lista circular de contactos, lista doblemente enlazada de correos, pila de papelera y cola de correos programados).
        ConvertirDotAPng, ConvertirDotAPngReportes	Procedimientos que utilizan la herramienta externa Graphviz (dot.exe) para convertir los archivos .dot (texto) en imágenes .png (gráficos).

### 1.4\. Diagrama de Relación

La siguiente imagen muestra la relación entre las estructuras de datos dentro del módulo de usuarios.

Fragmento de código

graph TD
    subgraph "Módulo de Usuarios"
        A[TUsuario] --> B(TListaCorreos);
        A --> C(TListaContactos);
        A --> D(TPila);
        A --> E(TCola);
    end

    subgraph "Lista de Usuarios"
        F[TListaUsuarios] --> A;
        A -- "siguiente" --> A;
    end
    
    style A fill:#ADD8E6,stroke:#333,stroke-width:2px;
    style B fill:#90EE90,stroke:#333,stroke-width:2px;
    style C fill:#FFFFE0,stroke:#333,stroke-width:2px;
    style D fill:#FFA07A,stroke:#333,stroke-width:2px;
    style E fill:#FFC0CB,stroke:#333,stroke-width:2px;
    style F fill:#ADD8E6,stroke:#333,stroke-width:2px;  `

*   TUsuario es el nodo principal que agrupa las otras estructuras.
    
*   TListaUsuarios contiene la lista de TUsuario.
    
*   Cada TUsuario tiene sus propias estructuras para inbox, contacts, papelera y programados.
    

### 1.5\. Consideraciones de Diseño

El diseño de este módulo permite una gestión de usuarios altamente organizada y escalable. La separación de responsabilidades en estructuras de datos anidadas facilita la manipulación de los correos y contactos de cada usuario sin afectar a la estructura principal de la lista de usuarios. El uso de la herramienta externa **Graphviz** para la generación de reportes visuales es un acierto, ya que externaliza el trabajo de visualización y permite que el código se enfoque en la lógica de datos.


### 2 Unidad de COntactos (Lista Doblemente Enlazada)

### 1\. Visión General

La unidad Contactos es un componente de la aplicación dedicado exclusivamente a la gestión de la lista de contactos de un usuario. Su principal característica es que implementa una **lista enlazada circular**, una estructura de datos que permite un acceso eficiente y un recorrido continuo de todos los contactos.

### 2\. Estructuras de Datos

El módulo define dos estructuras de datos principales para construir y gestionar la lista enlazada circular de contactos:

*   **TContacto**: Representa un nodo individual en la lista. A diferencia de una lista enlazada simple, el campo siguiente de este registro puede apuntar al primer nodo de la lista, creando un ciclo.
    
    *   correo (String): El correo electrónico del contacto, que sirve como identificador único.
        
    *   siguiente (**PContacto**): Un puntero al siguiente contacto en la secuencia de la lista.
        
*   **TListaContactos**: Esta es la estructura que administra la lista. Para optimizar las operaciones de inserción y recorrido, mantiene un puntero al último elemento en lugar de al primero.
    
    *   ultimo (**PContacto**): Un puntero al último nodo de la lista. En una lista enlazada circular, el último nodo apunta al primero, lo que permite un acceso rápido a ambos extremos de la lista.
        
    *   count (Integer): Un contador que rastrea el número total de contactos en la lista, lo que permite verificar fácilmente si la lista está vacía o si se necesita iterar un número específico de veces.
        

### 3\. Procedimientos y Funciones Clave

Este módulo expone los siguientes procedimientos y funciones para manipular la lista de contactos:

        InicializarListaContactos	Establece el estado inicial de la lista, configurando el puntero ultimo a nil y el contador count a cero.
        AgCont	Agrega un nuevo contacto a la lista. El procedimiento primero valida que el correo electrónico no exista ya en la lista. Si la validación es exitosa, el nuevo contacto se inserta eficientemente al final de la lista, manteniendo la propiedad circular.
        BuscarContacto	Recorre la lista enlazada circular para encontrar un contacto específico basándose en su dirección de correo electrónico. La búsqueda se realiza desde el primer nodo hasta que se encuentra el contacto o se completa un ciclo completo.
        ConvertirDotAPng	Un procedimiento auxiliar que utiliza la herramienta externa Graphviz para convertir un archivo de descripción de grafo (.dot) en una imagen (.png), permitiendo la visualización gráfica de la estructura de la lista de contactos.

### 3.4\. Diagrama de Relación

El siguiente diagrama ilustra la estructura de la lista enlazada circular de contactos. Nótese cómo el último nodo apunta de nuevo al primer nodo, formando el bucle.

graph TD
    A[Primer Contacto]
    B[Segundo Contacto]
    C[Tercer Contacto]
    D[Último Contacto]

    style A fill:#ADD8E6,stroke:#333,stroke-width:2px;
    style B fill:#ADD8E6,stroke:#333,stroke-width:2px;
    style C fill:#ADD8E6,stroke:#333,stroke-width:2px;
    style D fill:#ADD8E6,stroke:#333,stroke-width:2px;

    A --> B
    B --> C
    C --> D
    D --> A

### 3.5 Consideraciones de Diseño

La elección de una lista enlazada circular es una decisión de diseño optimizada para esta aplicación. Al mantener un puntero al último elemento, la función de agregar un contacto (AgCont) es muy eficiente, con una complejidad de tiempo de O(1). Por otro lado, la búsqueda de un contacto (BuscarContacto) recorre la lista completa en el peor de los casos, lo que tiene una complejidad de tiempo de O(n), donde n es el número de contactos. Este enfoque es adecuado para una lista de contactos que se espera que sea de un tamaño manejable. La capacidad de generar diagramas visuales con Graphviz es fundamental para la depuración y documentación del estado de la lista.


### 4 Unidad de Borradores (Árbol Binario de Búsqueda Auto-Balanceado - AVL)

### 4.1 Visión General

La unidad de Borradores está diseñada para gestionar la información de los correos no enviados por el usuario. La principal característica de diseño es la implementación de un Árbol Binario de Búsqueda AVL (Adelson-Velsky y Landis).

Esta elección garantiza que las operaciones de búsqueda, inserción y eliminación de borradores se realicen de manera altamente eficiente, manteniendo la estructura balanceada automáticamente, con una complejidad de tiempo de O(logn) en el peor de los casos. Los borradores se identifican y ordenan por un ID único asignado al momento de su creación.

### 4.2  Estructuras de Datos
Esta unidad se basa en la definición de dos estructuras principales, cuyo detalle se encuentra en la unidad Borrador (mencionada en el uses):

    TBorrador: Representa un nodo individual en el árbol, que contiene la información del correo no enviado.

    id (Integer): Clave de ordenamiento del árbol. Es el identificador único del borrador.

    destinatario, asunto, mensaje (String): Contenido del correo.

    izquierdo, derecho (PBorrador): Punteros a los nodos hijos izquierdo y derecho del árbol.

    factorEquilibrio (Integer): Almacena el factor de balance del nodo para la lógica de auto-balanceo del AVL.

    TListaBorradores: La estructura de control que administra el árbol.

    raiz (PBorrador): Puntero al nodo raíz del árbol AVL.


### 4.3 Procedimientos y Funciones Clave (Lógica de la Interfaz)
La unidad TFormBorradores expone los siguientes procedimientos que gestionan la interacción entre la interfaz gráfica (GUI) y la estructura de datos AVL.

Función/Procedimiento: LoadDrafts(traversalType: String)
Descripción: Procedimiento central que recupera los borradores del usuario y los carga en el TStringGrid de la interfaz.
Lógica de Datos Involucrada: Llama a los procedimientos de recorrido del AVL (RecorrerInOrden, RecorrerPreOrden, RecorrerPostOrden) para obtener la lista de borradores en el orden deseado.

Función/Procedimiento: DisplayDraft(borrador: PBorrador)
Descripción: Muestra los detalles de un borrador seleccionado en los campos de texto (EDestinatario, EAsunto, etc.).
Lógica de Datos Involucrada: Lógica de presentación de datos. Actualiza CurrentBorradorID.

Función/Procedimiento: StringGrid1SelectCell
Descripción: Maneja la selección de una fila en la cuadrícula.
Lógica de Datos Involucrada: Usa el ID de la fila seleccionada y llama a BuscarBorrador (O(logn)) en el AVL para recuperar todos los datos del borrador.

Función/Procedimiento: BOrderClick, BPOrderClick, BIOrderClick
Descripción: Botones que disparan la carga de la lista.
Lógica de Datos Involucrada: Llaman a LoadDrafts con parámetros 'INORDER', 'PREORDER' y 'POSTORDER' respectivamente, permitiendo al usuario ver la lista ordenada de diferentes maneras.

Función/Procedimiento: BEliminarClick
Descripción: Elimina el borrador actualmente seleccionado.
Lógica de Datos Involucrada: Llama a la función EliminarBorrador (O(logn)) del AVL, lo cual mantiene la propiedad de auto-balanceo. Recarga la lista después de la operación.

Función/Procedimiento: BEnviarClick
Descripción: Simula el envío y elimina el borrador.
Lógica de Datos Involucrada: Llama a EliminarBorrador (O(logn)), asumiendo que el borrador no es necesario una vez que el mensaje ha sido "enviado".

### 4.4 Diagrama de Relación
La siguiente imagen ilustra cómo la estructura del Árbol AVL de Borradores se anida en cada usuario.

Fragmento de código

        graph TD
            subgraph "Lista de Usuarios (Lista Simple)"
                U1[TUsuario 1]
                U2[TUsuario N]
                U1 -- "siguiente" --> U2
            end
            
            subgraph "Árbol AVL de Borradores"
                style R fill:#FFA07A,stroke:#333,stroke-width:2px;
                style B1 fill:#ADD8E6,stroke:#333,stroke-width:2px;
                style B2 fill:#ADD8E6,stroke:#333,stroke-width:2px;
                style B3 fill:#ADD8E6,stroke:#333,stroke-width:2px;
                
                R(Raíz - Borrador ID: 5)
                B1(Borrador ID: 3)
                B2(Borrador ID: 7)
                B3(Borrador ID: 10)
                
                R -- "izquierdo" --> B1
                R -- "derecho" --> B2
                B2 -- "derecho" --> B3
            end
            
            U1 -- "borradores" --> R
Cada TUsuario tiene su propio árbol AVL (TListaBorradores) independiente.

Los nodos (TBorrador) están ordenados por su campo id.

### 4.5 Consideraciones de Diseño
La elección del Árbol AVL es la decisión de diseño más importante en esta unidad:

Rendimiento Garantizado: La complejidad de O(logn) para la búsqueda y eliminación es ideal, incluso cuando el número de borradores del usuario sea grande, superando la eficiencia de una lista lineal (O(n)).

Recorridos Flexibles: La naturaleza del árbol permite implementar fácilmente los tres recorridos principales (INORDER, PREORDER, POSTORDER). El INORDER es crucial, ya que recupera los borradores ordenados automáticamente por su ID, que es el comportamiento de visualización por defecto.

Integración con GUI: La interfaz utiliza el TStringGrid para mostrar el resultado de los recorridos, y la función BuscarBorrador con el ID es vital para cargar el contenido completo de un borrador al seleccionarlo.

### 5 Unidad de Favoritos (Árbol B - B-Tree)
### 5.1. Visión General
La unidad de Favoritos está diseñada para gestionar la lista de correos marcados por el usuario, priorizando la escalabilidad y la eficiencia en el almacenamiento secundario.

La estructura de datos elegida es un Árbol B (B-Tree), una estructura auto-balanceada y de múltiples vías, ideal para sistemas donde el volumen de datos es grande. En este contexto de gestión de correos, el Árbol B se utiliza para ordenar y buscar los correos favoritos por su ID único de manera extremadamente eficiente, garantizando una complejidad de tiempo de O(log 
t
​
 n) para las operaciones clave, donde t es el orden (grado mínimo) del árbol.

### 5.2. Estructuras de Datos
La lógica interna del Árbol B (unidades Favorito o Correos) define las siguientes estructuras de control avanzadas:

    TClaveB: Representa una entrada dentro de un nodo.

    correo_link (PCorreo): Un puntero al correo real almacenado en otra estructura (e.g., el inbox), evitando la duplicación del mensaje.

    TNodeB (PNodeB): El nodo fundamental del Árbol B.

    count (Integer): Número actual de claves en el nodo.

    is_leaf (Boolean): Indica si el nodo es una hoja.

    claves (Array of TClaveB): Arreglo que contiene las claves ordenadas (IDs de correo).

    hijos (Array of PNodeB): Arreglo de punteros a los nodos hijos.

    TListaFavoritos: La estructura principal que administra el Árbol B.

    raiz (PNodeB): Puntero al nodo raíz del Árbol B.    

Relación con la Unidad de Usuarios:
La estructura TUsuario (Sección 1) contiene el campo favoritos de tipo TListaFavoritos, encapsulando el Árbol B dentro de cada perfil de usuario.

### 5.3 Procedimientos y Funciones Clave (Lógica de la Interfaz)
    Función/Procedimiento: RecorrerArbolParaGrilla
    Descripción: Realiza un recorrido In-Orden del Árbol B, visitando primero el subárbol izquierdo, luego las claves y finalmente el subárbol derecho.
    Lógica de Datos Involucrada: Extrae los datos del árbol y los carga en el TStringGrid ordenados por ID.
    Complejidad: O(n)

    Función/Procedimiento: CargarFavoritosEnGrid
    Descripción: Inicializa la cuadrícula y llama a la función de recorrido.
    Lógica de Datos Involucrada: Gestiona la interfaz y garantiza que solo se recorra la estructura si existe una raíz.
    Complejidad: O(n)

    Función/Procedimiento: ActualizarContador
    Descripción: Muestra el número total de favoritos.
    Lógica de Datos Involucrada: Llama a la función externa ContarClaves, que recorre el árbol para obtener el total.
    Complejidad: O(n)

    Función/Procedimiento: GCorreosSelectCell
    Descripción: Maneja la selección de un correo en la cuadrícula.
    Lógica de Datos Involucrada: Utiliza el ID seleccionado y llama a BuscarClave en el Árbol B para recuperar los detalles.
    Complejidad: O(log 
    t
    ​
    n)

    Función/Procedimiento: BeliminarClick
    Descripción: Elimina el correo seleccionado de la lista de favoritos.
    Lógica de Datos Involucrada: Llama a la función EliminarClave del Árbol B, la cual es responsable de la eliminación y el rebalanceo de la estructura.
    Complejidad: O(log 
    t
    ​
    n)

### 5.4 Consideraciones de Diseño
Alto Rendimiento Garantizado: La complejidad de O(log 
t
​
 n) para las operaciones de búsqueda y eliminación es la principal ventaja, ya que el Árbol B garantiza que el rendimiento no se degradará significativamente incluso si la lista de favoritos crece exponencialmente.

Referencia a Datos: El diseño es eficiente al almacenar solo una referencia (correo_link) al mensaje original, lo que reduce el consumo de memoria.

Ordenamiento Intrínseco: El recorrido In-Orden del Árbol B asegura que la lista de favoritos se cargue siempre ordenada por el ID, proporcionando un listado consistente y predecible al usuario.
