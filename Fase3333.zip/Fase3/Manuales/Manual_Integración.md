Manual Técnico: Módulo de Comunidades
=====================================

El módulo de comunidades, implementado en la unidad Comunidades.pas, permite al usuario administrador la creación y gestión de grupos de usuarios. La estructura de datos fundamental es un **Arbol BST**, una elección de diseño que facilita la organización y el reporte visual de las comunidades y sus miembros.

1\. Estructura de Datos
-----------------------

La lógica de este módulo se basa en tres estructuras de datos interconectadas:

*   **TListaComunidades**: Una lista enlazada simple que funciona como el punto de entrada principal. Cada nodo en esta lista es de tipo PComunidad.
    
*   **TArbol**: Representa una comunidad individual. Además de su nombre, cada Atbol tiene sus nodos que incluyen las caracteristicas de cada comunidad que almacena a todos los miembros de esa comunidad a la vez que sus mensajes.
    
*   **TListaUsuariosComunidad**: La lista de usuarios dentro de una comunidad. Cada uno de sus nodos (TUsuarioComunidad) contiene un puntero a un usuario existente en la lista global (PUsuario). Esto evita la duplicación de datos de usuario.

*   **TListaUsuariosComunidad**: Una lista simple que contiene los mensajes que los usuarios envian a sus comunidades.
    

            // Nodo para la lista de usuarios en una comunidad
            PUsuarioComunidad = ^TUsuarioComunidad;
            TUsuarioComunidad = record
            usuario: PUsuario; // Puntero al usuario en la lista principal
            siguiente: PUsuarioComunidad;
            end;

            TListaUsuariosComunidad = record
            primero: PUsuarioComunidad;
            ultimo: PUsuarioComunidad;
            count: Integer;
            end;

            //(NODO DEL BST)
            PComunidad = ^TComunidad;
            TComunidad = record
            nombre: string;
            fechaCreacion: TDateTime;
            numMensajes: Integer; // Contador local de mensajes

            // Punteros del BST
            izquierdo: PComunidad;
            derecho: PComunidad;

            // Listas internas
            mensajes: TListaMensajes;
            miembros: TListaUsuariosComunidad;
            end;

            // ESTRUCTURA DEL ÁRBOL
            TArbolComunidades = record
            raiz: PComunidad;
            count: Integer;
            end;





2\. Implementación de Procedimientos
------------------------------------

El código está organizado en procedimientos y funciones que manipulan estas estructuras:

### 2.1. Gestión de la lista de comunidades

*   InicializarListaComunidades: Inicializa la lista principal, estableciendo el primer puntero en nil.
    
*   CrearComunidad: Crea un nuevo nodo TComunidad con un nombre único y lo añade al final de ListaComunidades.
    
*   BuscarComunidad: Recorre la lista de comunidades para encontrar un nodo por su nombre, lo que es esencial para agregarle usuarios.
    

### 2.2. Gestión de usuarios en comunidades

*   AgregarUsuarioAComunidad: El corazón de la lista de listas. Esta función busca un usuario en la lista global de usuarios y crea un nuevo nodo de tipo TUsuarioComunidad para la lista interna de la comunidad. Se incluye una validación para evitar que el mismo usuario sea agregado dos veces a la misma comunidad.
    

### 2.3. Interacción con la interfaz de usuario

Los siguientes procedimientos, en la clase TFormComunidades, conectan la lógica de las estructuras con los elementos visuales del formulario:

*   BcrearClick: Se activa al hacer clic en el botón de "Crear". Llama a CrearComunidad con el nombre del TEdit y luego actualiza el TComboBox con todos los nombres de las comunidades para reflejar los cambios.
    
*   BagregarClick: Maneja la adición de usuarios. Primero, busca la comunidad seleccionada y luego el usuario por correo electrónico. Si ambos existen, llama a AgregarUsuarioAComunidad.

### 2.4 Formulario final de la unidad comunidades hecho por mi persona
![form](image-1.png)
    

3\. Generación de Reportes
--------------------------

El módulo incluye una función para generar un reporte visual de la estructura completa en un archivo PNG.

*   GenerarReporteComunidades: Este procedimiento crea un archivo .dot que describe la estructura de la lista de listas. La implementación sigue el siguiente patrón para obtener el diseño deseado:
    
    1.  Escribe la cabecera del dot con la dirección del grafo (rankdir=LR).
        
    2.  Recorre la lista de comunidades para crear un **nodo independiente** por cada comunidad, lo que permite dibujar las flechas entre ellas.
        
    3.  A continuación, recorre la lista de comunidades una segunda vez para generar los nodos de usuario y sus conexiones. Las flechas verticales se crean conectando cada nodo de comunidad con el primer usuario de su lista interna.
        
    4.  Finalmente, se llama a la función ConvertirDotAPng para procesar el archivo .dot y generar el reporte visual.

### 3.1  Este es el codigo final de mi parte para convertir la estructura de las comunidades a un archivo dot.

        

        procedure GenerarReporteComunidades(arbol: TArbolComunidades; nombreArchivo: string);
        var
        archivo: TextFile;
        rutaCompleta, rutaCarpeta: string;
        begin
        if arbol.raiz = nil then
        begin
            ShowMessage('No hay comunidades para generar un reporte.');
            Exit;
        end;

        rutaCarpeta := ExtractFilePath(ParamStr(0)) + 'Root-Reportes';
        if not DirectoryExists(rutaCarpeta) then
            CreateDir(rutaCarpeta);

        rutaCompleta := rutaCarpeta + DirectorySeparator + nombreArchivo + '.dot';
        AssignFile(archivo, rutaCompleta);
        Rewrite(archivo);

        try
            Writeln(archivo, 'digraph BSTComunidades {');
            Writeln(archivo, '  rankdir=TB;'); // Dibuja el BST de Arriba a Abajo (Top-Bottom)
            Writeln(archivo, '  node [style=filled];');
            Writeln(archivo, '  edge [dir=forward];');
            Writeln(archivo, '  splines=polyline;');
            Writeln(archivo, '  graph [label="Reporte de Comunidades ", labelloc=t, fontname="Arial"];');


            GenerarNodosBST(archivo, arbol.raiz);
            GenerarEnlacesBST(archivo, arbol.raiz);

            Writeln(archivo, '}');
            CloseFile(archivo);

            ConvertirDotAPng(nombreArchivo);

            ShowMessage('Reporte de comunidades generado exitosamente.');
        except
            on E: Exception do
            ShowMessage('Error al generar el reporte de comunidades: ' + E.Message);
        end;
        end;

### 3.2 Esta es la imagen de como quedaria el reporte una vez generado

![alt text](image-16.png)

### 3.3 Adicionalmente se puede crear un reporte simple que ilustra solamente los emnsajes en las comunidades sin mostrar sus miembros ni la informcaion base de la comunidad.

![alt text](image-17.png)

4\. Origen de la Estructura
--------------------------
La estructura se creo a partir de un repositorio en el cual todos los integrantes aportaban ideas y conceptos sobre como manejar los datos

1.  Imagen del repositorio conjunto

![repo](/Manuales/repo.png)

2. Estructura preliminar para manejar el nodo de la lista comunidades

                type
                PComunity = ^TComunity;
                TComunity = record
                    Head: PNode;
                    Last: PNode;
                    Size: Integer;
                end;
                procedure InitComunity(var com: PComunity);
                procedure AddListToComunity(var com: PComunity; list: PList);

3. Formulario Base propuesto por uno de nuestros integrantes

![front preliminar](image.png)

4. Codigo Preliminar para crear un archivo dot de la unidad de comunidades

        // Procedimiento para realizar el archivo DOT 

        procedure GenerarArchivoDOT(const ListaComunidades: TListaComunidades; const ArchivoSalida: string);
        var
        F: TextFile;
        ComunidadActual: PComunidad;
        UsuarioActual: PUsuario;
        begin
        AssignFile(F, ArchivoSalida);
        Rewrite(F);

        Writeln(F, 'digraph Comunidades {');
        Writeln(F, '  rankdir=LR;');
        Writeln(F, '  node [shape=box, style=filled, color=lightskyblue];');

        // Recorrer la lista de comunidades
        ComunidadActual := ListaComunidades;
        while ComunidadActual <> nil do
        begin
            // Crear el nodo para la comunidad
            Writeln(F, '  "' + ComunidadActual^.Nombre + '" [shape=Mrecord, fillcolor=lightgreen];');

            // Recorrer la lista de usuarios de la comunidad actual
            UsuarioActual := ComunidadActual^.Usuarios;
            while UsuarioActual <> nil do
            begin
            // Crear el nodo para el usuario
            Writeln(F, '  "' + UsuarioActual^.Nombre + '" [shape=oval, fillcolor=lightblue];');

            // Crear la conexión de la comunidad al usuario
            Writeln(F, '  "' + ComunidadActual^.Nombre + '" -> "' + UsuarioActual^.Nombre + '";');

            // Avanzar al siguiente usuario
            UsuarioActual := UsuarioActual^.Siguiente;
            end;

            // Avanzar a la siguiente comunidad
            ComunidadActual := ComunidadActual^.Siguiente;
        end;

        Writeln(F, '}');
        CloseFile(F);
        end;