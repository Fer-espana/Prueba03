Manual De Usuario
=====================================

Este manual esta orientado a proporcionar documentacion sobre el flujo del programa de vforma visual y que componentes lo integran.

### Login

![alt text](image-2.png)

### Registro (Usuario)

![alt text](image-5.png)


### Administrador (ROOT)

![alt text](image-3.png)

### Seccion de COmunidades (ROOT)

![alt text](image-4.png)

### Interfaz de Usuario (Usuario)

![alt text](image-6.png)

### Bandeja de Entrada (Usuario)

![alt text](image-7.png)

### Enviar Correo (Usuario)

![alt text](image-8.png)

### Papelera (Usuario)

![alt text](image-9.png)

### Programar Correo (Usuario)

![alt text](image-10.png)

### Agregar Contactos (Usuario)

![alt text](image-11.png)

### Contactos (Usuario)

![alt text](image-12.png)

### Actualizar Perfil (Usuario)

![alt text](image-13.png)

### Publicar Mensajes en la Comunidad (Usuario)

![alt text](image-14.png)

### Borradores (Usuario)

![alt text](image-15.png)